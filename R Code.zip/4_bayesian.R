
################### set up and run Bayesian models ##########################

##########################################################
#      RUN "2_analysis.R" BEFORE RUNNING THIS FILE       #        
##########################################################

# See this website for documentation on how to install the 
# rethinking package: https://github.com/rmcelreath/rethinking

library(rethinking)
library(cowplot)
library(scales) # used for smoothed histogram of r values
library(forcats)

########## function to put histograms in the pairs() charts  ####
panel.hist <- function(x, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(usr[1:2], 0, 1.5) )
  h <- hist(x, plot = FALSE)
  breaks <- h$breaks; nB <- length(breaks)
  y <- h$counts; y <- y/max(y)
  rect(breaks[-nB], 0, breaks[-1], y, col = "cyan", ...)
}

######### Input Data #####################
setwd(wd_output)
dataset_2016 = sap_data_2016[!is.na(sap_data_2016$avg_v), ] %>%
  mutate(species_dummy = NA,
         species_index = NA,
         site_index = NA,
         day = NA,
         log_avg_v = NA)
dataset_2016$species_dummy[dataset_2016$species=="juniper"] <- 0
dataset_2016$species_dummy[dataset_2016$species=="oak"] <- 1
dataset_2016$species_dummy <- as.integer(dataset_2016$species_dummy)
dataset_2016$species_index[dataset_2016$species=="juniper"] <- 1
dataset_2016$species_index[dataset_2016$species=="oak"] <- 2
dataset_2016$species_index <- as.integer(dataset_2016$species_index)
dataset_2016$site_index[dataset_2016$site=="A"] <- 1
dataset_2016$site_index[dataset_2016$site=="B"] <- 2
dataset_2016$site_index[dataset_2016$site=="C"] <- 3
dataset_2016$day = as.integer(dataset_2016$date - ds_2017_2_adj[1])
tree_list_2016 = unique(dataset_2016$tree) 
tree_index_2016 = seq(1, length(tree_list_2016), 1)
tree_index_table_2016 = data.frame(tree = tree_list_2016, tree_index = tree_index_2016)
dataset_2016 = left_join(dataset_2016, tree_index_table_2016, by=c("tree"))
dataset_2016$tree_index <- as.integer(dataset_2016$tree_index)

dataset_2017 = sap_data_2017[!is.na(sap_data_2017$avg_v), ] %>%
  mutate(species_dummy = NA,
         species_index = NA,
         site_index = NA,
         day = NA,
         log_avg_v = NA)
dataset_2017$species_dummy[dataset_2017$species=="juniper"] <- 0
dataset_2017$species_dummy[dataset_2017$species=="oak"] <- 1
dataset_2017$species_dummy <- as.integer(dataset_2017$species_dummy)
dataset_2017$species_index[dataset_2017$species=="juniper"] <- 1
dataset_2017$species_index[dataset_2017$species=="oak"] <- 2
dataset_2017$species_index <- as.integer(dataset_2017$species_index)
dataset_2017$site_index[dataset_2017$site=="D"] <- 4
dataset_2017$site_index[dataset_2017$site=="E"] <- 5
dataset_2017$site_index[dataset_2017$site=="F"] <- 6
dataset_2017$day = as.integer(dataset_2017$date - ds_2017_2_adj[1])
dataset_2017$log_avg_v = log(dataset_2017$avg_v)
tree_list_2017 = unique(dataset_2017$tree) 
tree_index_2017 = seq(length(tree_list_2016) + 1, length(tree_list_2016) + length(tree_list_2017), 1)
tree_index_table_2017 = data.frame(tree = tree_list_2017, tree_index = tree_index_2017)
dataset_2017 = left_join(dataset_2017, tree_index_table_2017, by=c("tree"))
dataset_2017$tree_index <- as.integer(dataset_2017$tree_index)

tree_list = c(tree_list_2016, tree_list_2017)
dataset_2016_1_center = round(mean(seq(ds_2016_1_adj[1], ds_2016_1_adj[2], 1)), 0)
dataset_2017_1_center = round(mean(seq(ds_2017_1_adj[1], ds_2017_1_adj[2], 1)), 0)
dataset_2017_2_center = round(mean(seq(ds_2017_2_adj[1], ds_2017_2_adj[2], 1)), 0)
dataset_2017_3_center = round(mean(seq(ds_2017_3_adj[1], ds_2017_3_adj[2], 1)), 0)

dataset_2016_1 = filter(dataset_2016,
                        date >= ds_2016_1_adj[1],
                        date <= ds_2016_1_adj[2]) %>%
                 mutate(period2016 = 1, period1 = 0, period2=0, period3=0,
                        day_cent = as.integer(date - dataset_2016_1_center),
                        period = "period2016")
dataset_2017_1 = filter(dataset_2017, 
                        date >= ds_2017_1_adj[1],
                        date <= ds_2017_1_adj[2]) %>%
                 mutate(period2016 = 0, period1 = 1, period2=0, period3=0,
                        day_cent = as.integer(date - dataset_2017_1_center),
                        period = "period2017_1")
dataset_2017_2 = filter(dataset_2017, 
                        date >= ds_2017_2_adj[1],
                        date <= ds_2017_2_adj[2]) %>%
                 mutate(period2016 = 0, period1 = 0, period2=1, period3=0,
                        day_cent = as.integer(date - dataset_2017_2_center),
                        period = "period2017_2")
dataset_2017_3 = filter(dataset_2017, 
                        date >= ds_2017_3_adj[1],
                        date <= ds_2017_3_adj[2]) %>%
                 mutate(period2016 = 0, period1 = 0, period2=0, period3=1,
                        day_cent = as.integer(date - dataset_2017_3_center),
                        period = "period2017_3")
dataset_2017_dry = rbind(dataset_2017_1, dataset_2017_2, dataset_2017_3)
dataset_dry = rbind(dataset_2016_1,dataset_2017_1, dataset_2017_2, dataset_2017_3)
dataset_dry_tree_start = group_by(dataset_dry, tree, period2016, period1, period2, period3) %>%
  filter(date %in% c(ds_2016_1_adj[1], ds_2017_2_adj[1], ds_2017_3_adj[1])) %>%
  summarize(tree_start = max(avg_v))
dataset_dry_tree_start_period1 = filter(dataset_dry, period1 == 1) %>%
  group_by(tree, period2016, period1, period2, period3)
dataset_dry_tree_start_period1_mindate = summarize(dataset_dry_tree_start_period1, mindate = min(date))
dataset_dry_tree_start_period1 = left_join(dataset_dry_tree_start_period1, dataset_dry_tree_start_period1_mindate) %>%
  filter(date == mindate) %>%
  summarize(tree_start = max(avg_v))
dataset_dry_tree_start = rbind(dataset_dry_tree_start, dataset_dry_tree_start_period1)

dataset_dry = left_join(dataset_dry, dataset_dry_tree_start) %>%
  mutate(avg_v_std = avg_v/tree_start)
dataset_dry$latin[dataset_dry$species_dummy==0] <- "J. ashei"
dataset_dry$latin[dataset_dry$species_dummy==1] <- "Q. fusiformis"

#combine tree_index and dry period into one index
dataset_dry$tree_period_index <- as.integer(dataset_dry$tree_index +
                                 11*dataset_dry$period2 +
                                 22*dataset_dry$period3)

######### data 2016 & 2017 - all dry-downs ################
# multilevel model, with level for species, avg_v, centered data
# species uses dummy variable, so species do not inform each other
dataset_dry.trim = select(dataset_dry, species_dummy, species_index, 
                          tree_index, tree_period_index, site_index, date, day_cent, 
                          period2016, period1, period2, period3,  
                          avg_v)
center_a_exp.a = filter(dataset_dry.trim, day_cent == 0) %>%
  select(avg_v)
center_a_exp.b = nrow(center_a_exp.a)
center_a_exp = prod(center_a_exp.a) ^ (1/center_a_exp.b)
dataset_dry.trim = mutate (dataset_dry.trim,
                           avg_v_cent = avg_v / center_a_exp)
# Subset dataset
dataset_dry.trim.subset = select(dataset_dry.trim, 
                                 avg_v_cent, day_cent, species_dummy, tree_index, 
                                 tree_period_index, site_index)

################## Descriptions ###########################
# Model1: species and site ignored
# Model2: r varies by species.
# Model3: r varies by species and site.  <-- This is the chosen model for our paper
# Model4: r varies by site.

########### Model 1 ####################################
model1 <- map2stan(
  alist(
    avg_v_cent ~ dnorm(mu,sigma),
    mu <- a * exp(r * day_cent),
    a <- a_tree[tree_period_index],
    a_tree[tree_period_index] ~ dnorm(a_mean, a_sigma_tree),
    a_mean ~ dnorm(0,1),
    a_sigma_tree ~ dcauchy(0,1),
    r <- r_tree[tree_index],
    r_tree[tree_index] ~ dnorm(0, r_sigma_tree), 
    r_sigma_tree ~ dcauchy(0, 0.1),
    sigma ~ dcauchy(0,1)
  ),
  data=as.data.frame(dataset_dry.trim.subset,tree_index), 
  iter=20000, # 20000 run, 28 transitions > maximum treedepth
  warmup = 10000, 
  control = list(max_treedepth = 12, adapt_delta = 0.80),
  chains = 4
)
divergent(model1)
precis(model1, prob=0.95)
precis(model1, depth=2, digits=2, prob=0.95)

########### Model 2 ####################################
model2 <- map2stan(
  alist(
    avg_v_cent ~ dnorm(mu,sigma),
    mu <- a * exp(r * day_cent),
    a <- a_tree[tree_period_index],
    a_tree[tree_period_index] ~ dnorm(a_mean, a_sigma_tree),
    a_mean ~ dnorm(0,1),
    a_sigma_tree ~ dcauchy(0,1),
    r <- r_mean_site + r_diff*species_dummy + r_tree[tree_index],
    r_mean_site ~ dnorm(0, 0.1),
    r_diff ~ dnorm(0, 0.1),
    r_tree[tree_index] ~ dnorm(0, r_sigma_tree), 
    r_sigma_tree ~ dcauchy(0, 0.1),
    sigma ~ dcauchy(0,1)
  ),
  data=as.data.frame(dataset_dry.trim.subset,tree_index), 
  iter=20000, # 20000 run, 28 transitions > maximum treedepth
  warmup = 10000, 
  control = list(max_treedepth = 12, adapt_delta = 0.80),
  chains = 4
)
divergent(model2)
precis(model2, prob=0.95)
precis(model2, depth=2, digits=2, prob=0.95)

########### Model 3 ####################################
model3 <- map2stan(
  alist(
    avg_v_cent ~ dnorm(mu,sigma),
    mu <- a * exp(r * day_cent),
    a <- a_tree[tree_period_index],
    a_tree[tree_period_index] ~ dnorm(a_mean, a_sigma_tree),
    a_mean ~ dnorm(0,1),
    a_sigma_tree ~ dcauchy(0,1),
    r <- r_jun_site[site_index] + r_diff*species_dummy + r_tree[tree_index],
    r_jun_site[site_index] ~ dnorm(r_mean_site, r_sigma_site),
    r_mean_site ~ dnorm(0, 0.1),
    r_sigma_site ~ dcauchy(0, 0.1),
    r_diff ~ dnorm(0, 0.1),
    r_tree[tree_index] ~ dnorm(0, r_sigma_tree), 
    r_sigma_tree ~ dcauchy(0, 0.1),
    sigma ~ dcauchy(0,1)
  ),
  data=as.data.frame(dataset_dry.trim.subset,tree_index), 
  iter=20000, # 20000 run, 28 transitions > maximum treedepth
  warmup = 10000, 
  control = list(max_treedepth = 12, adapt_delta = 0.80),
  chains = 4
)
divergent(model3)
precis(model3, prob=0.95)
precis(model3, depth=2, digits=2, prob=0.95)
post3 <- extract.samples(model3)
plot(model3)
dev.off()
pairs(post3[c("r_jun_site", "r_diff")]) # all of the r_site params are negatively correlated with r_mean_jun 
plot(precis(model3, prob=0.95))
plot(precis(model3, prob=0.95, depth=2))
plot(precis(model3, prob=0.95, depth=2, pars = c("r_jun_site", "r_diff", "r_site")))
plot(precis(model3, prob=0.95, depth=2, pars = c("r_tree")))

# values for paper
model3_rdiff = post3$r_diff    # r_diff = differences between oak and juniper species r values
sum(model3_rdiff<=0)           # count of r_diff values less than 0
1-sum(model3_rdiff<=0)/40000   # based on 40000 models run, percentage of r_diff values greater than zero,
                               # i.e. percentage of models that support hypothesis
precis(model3, prob=0.95, depth=2, digits=4, pars = c("r_mean_site", "r_diff"))

########### Model 4 ####################################
model4 <- map2stan(
  alist(
    avg_v_cent ~ dnorm(mu,sigma),
    mu <- a * exp(r * day_cent),
    a <- a_tree[tree_period_index],
    a_tree[tree_period_index] ~ dnorm(a_mean, a_sigma_tree),
    a_mean ~ dnorm(0,1),
    a_sigma_tree ~ dcauchy(0,1),
    r <- r_jun_site[site_index] + r_tree[tree_index],
    r_jun_site[site_index] ~ dnorm(r_mean_site, r_sigma_site),
    r_mean_site ~ dnorm(0, 0.1),
    r_sigma_site ~ dcauchy(0, 0.1),
    r_tree[tree_index] ~ dnorm(0, r_sigma_tree), 
    r_sigma_tree ~ dcauchy(0, 0.1),
    sigma ~ dcauchy(0,1)
  ),
  data=as.data.frame(dataset_dry.trim.subset,tree_index), 
  iter=20000, # 20000 run, 28 transitions > maximum treedepth
  warmup = 10000, 
  control = list(max_treedepth = 12, adapt_delta = 0.80),
  chains = 4
)
divergent(model4)
precis(model4, prob=0.95)
precis(model4, depth=2, digits=2, prob=0.95)

################# Compare Models ###################
# Model comparisons
compare(model1, model2, model3, model4) # model comparison using WAIC 
plot(compare(model1, model2, model3, model4))
coeftab(model1, model2, model3, model4, digits=4) # mean parameter values compared across models
plot(coeftab(model1, model2, model3, model4))

################# Final Plots for Model 3 (chosen model) ##################

########### r_diff probability density #################
r_diff.3 = post3$r_diff
r_df.3 = data.frame(r_diff = r_diff.3)

length(r_diff.3[r_diff.3 > 0])/length(r_diff.3)
length(r_diff.3[r_diff.3 <= 0])

ggplot(data = r_df.3, mapping = aes(r_diff)) + 
  geom_hline(yintercept = 0, color="black", size = 0.2) +
  geom_vline(xintercept = 0, color="black", size = 0.2) +
  geom_line(stat="density", size = 0.5) +
  geom_vline(xintercept = mean(r_df.3$r_diff), color = "red", linetype="dashed") +
  ggtitle(expression(paste("Probability Density for ",italic("r")[diff]))) +
  xlab(expression(italic("r")[diff])) +
  ylab("Density") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        #text=element_text(family="Times New Roman"),
        axis.title.x = element_text(size = 13),
        plot.title = element_text(hjust=0.5))
ggsave(paste(wd_charts,"/Figure 7.tiff",sep=""), 
       units="in", width=4, height=4, dpi=600, compression = 'lzw')

########### Table of output values (for charts) ###################

# calculate average model values
r_list = c()
r_025_list = c()
r_975_list = c()
tree_list = c()
tree_period_list = c()
dummy_list = c()
site_list = c()
for (tree_period in 1:45){
  dataset_tree = filter(dataset_dry.trim, tree_period_index == tree_period)
  tree_i = dataset_tree$tree_index[1] #first value, as values are all the same for a given tree
  site_i = dataset_tree$site_index[1] 
  species_dummy = dataset_tree$species_dummy[1] # same as above
  
  a <- center_a_exp * (post3$a_tree[ , tree_period])
  r <- post3$r_jun_site[ , site_i] + 
    post3$r_diff*species_dummy + post3$r_tree[ , tree_i]  
  
  avg_a = mean(a)
  avg_r = mean(r)
  r_025 = quantile(r, 0.025)
  r_975 = quantile(r, 0.975)
  
  tree_peirod_list = c(tree_period_list, tree_period)
  tree_list = c(tree_list, tree_i)
  dummy_list = c(dummy_list, species_dummy)
  site_list = c(site_list, site_i)
  r_list = c(r_list, avg_r)
  r_025_list = c(r_025_list, r_025)
  r_975_list = c(r_975_list, r_975)
  dataset_tree$mean_model = (avg_a) * exp(avg_r * (dataset_tree$day_cent))
  if(tree_i==1){model3_output = dataset_tree}
  if(tree_i>1){model3_output = rbind(model3_output, dataset_tree)}
}

dataset_tree_summary = data.frame(tree_period_index = tree_period,
                                  tree_index = tree_list,
                                  species_dummy = dummy_list,
                                  site_index = site_list,
                                  avg_r = r_list,
                                  r_025 = r_025_list,
                                  r_975 = r_975_list
)
dataset_tree_summary$site_name[dataset_tree_summary$site_index==1] <- "A"
dataset_tree_summary$site_name[dataset_tree_summary$site_index==2] <- "B"
dataset_tree_summary$site_name[dataset_tree_summary$site_index==3] <- "C"
dataset_tree_summary$site_name[dataset_tree_summary$site_index==4] <- "D"
dataset_tree_summary$site_name[dataset_tree_summary$site_index==5] <- "E"
dataset_tree_summary$site_name[dataset_tree_summary$site_index==6] <- "F"
dataset_tree_summary$latin[dataset_tree_summary$species_dummy==0] <- "J. ashei"
dataset_tree_summary$latin[dataset_tree_summary$species_dummy==1] <- "Q. fusiformis"
dataset_tree_summary = mutate(dataset_tree_summary,
                              site = site_index + 0.15*(tree_index %% 2))

model3_output$species[model3_output$species_dummy == 0] <- "juniper"
model3_output$species[model3_output$species_dummy == 1] <- "oak"
model3_output$species = factor(model3_output$species, levels = c("juniper", "oak"))
model3_output$latin = "Q. fusiformis"
model3_output$latin[model3_output$species == "juniper"] = "J. ashei"
model3_output = mutate(model3_output,
                         sap_movement = avg_v * 1440 / 1000) # units: m

########### model 3: plot of r values by tree, site, species ########
plot_model_3_tree_r = ggplot(dataset_tree_summary, 
                             mapping = aes(x=site, y=avg_r, color=latin)) +
  geom_hline(yintercept=0, size = 0.2, color="gray") +
  geom_errorbar(aes(ymin = r_025, ymax = r_975), width = 0.2) +
  geom_point() +
  scale_x_continuous(breaks=c(1,2,3,4,5,6),
                     labels=c("A", "B", "C", "D", "E", "F")) +
  ggtitle("Relative Rate of Change in Sap Velocity by Tree") +
  xlab("Site") +
  ylab("Relative Rate of Change") +
  labs(color="species") +
  guides(color = guide_legend(title = "Species")) +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(), 
        #text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5), #centers title
        legend.position="right",
        legend.text = element_text(face = "italic", size=10.5))
plot_model_3_tree_r
ggsave(paste(wd_charts,"/Figure 6.tiff",sep=""), 
       units="in", width=6, height=4, dpi=600, compression = 'lzw')

########### model 3: 2016 results plot #####
model3_output_2016 = filter(model3_output, tree_index <= 12) %>%
  mutate(mean_model_movement = mean_model * 1.44)
plot_model3_2016 = ggplot(model3_output_2016) +
  geom_hline(yintercept = 0, size = 0.1) +
  geom_point(mapping = aes(date, avg_v, shape=latin, color=latin), alpha = 0.6) +
  geom_line(mapping = aes(date, mean_model, group = tree_index, linetype=latin)) +
  scale_x_date(breaks = c(ymd("20160715"),ymd("20160801"),ymd("20160815")),
               date_labels = "%b %d",
               limits=c(ymd("20160723"),ymd("20160818"))) +
  ylim(0,3) +
  xlab("2016") +
  ylab("Daily Mean Sap Velocity (mm/min)") +
  labs(color="Measured Values",
       shape="Measured Values",
       linetype="Mean Model") +
  guides(color = guide_legend(order=1),
         shape = guide_legend(order=1),
         linetype = guide_legend(order=2)) +
  ggtitle("") +
  theme_bw() +
  theme(legend.position = "none") + #remove all legends (for cowplot)
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        #axis.title.y = element_text(size = 12),
        #text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5), #centers title
        legend.text = element_text(face = "italic")) 
plot_model3_2016
label1 = "(1)"
plot_model3_2016_labeled <- ggdraw(plot_model3_2016) +
                              draw_label(label1, x = 0.6, y = 0.85, size = 10)
plot_model3_2016_labeled

plot_model3_2016_std = ggplot(dataset_dry) +
  geom_hline(yintercept = 0, size = 0.1) +
  #geom_point(mapping = aes(date, avg_v_std, shape=latin, color=latin), alpha = 0.6) +
  geom_line(mapping = aes(date, avg_v_std, color=latin, group = tree_index)) +
  #geom_line(mapping = aes(date, mean_model, group = tree_index, linetype=latin)) +
  scale_x_date(breaks = c(ymd("20160715"),ymd("20160801"),ymd("20160815")),
               date_labels = "%b %d",
               limits=c(ymd("20160723"),ymd("20160818"))) +
  #scale_y_continuous(breaks=c(0,1,2), labels = c("0","1","")) +
  ylim(0,3) +
  xlab("2016") +
  ylab("Standardized Sap Velocity (no units)") +
  labs(color="measured values",
       shape="measured values",
       linetype="mean model") +
  guides(color = guide_legend(order=1),
         shape = guide_legend(order=1),
         linetype = guide_legend(order=2)) +
  #ggtitle("Measured vs. Modeled Sap Flow During 2016 Dry Periods") +
  theme_bw() +
  theme(legend.position = "none", #remove all legends (for cowplot)
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        #text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5), #centers title
        legend.text = element_text(face = "italic")) 
plot_model3_2016_std

########### model 3: 2017 results plot #######

# dataprep
model3_output_2017 = filter(model3_output, tree_index > 12)
model3_output_2017$period[model3_output_2017$period1 == 1] <- "period2017_1"
model3_output_2017$period[model3_output_2017$period3 == 1] <- "period2017_3"
model3_output_2017$period[is.na(model3_output_2017$period)] <- "period2017_2"
model3_output_2017 = mutate(model3_output_2017, 
                            groupname = paste(period, "_", tree_index),
                            mean_model_movement = mean_model * 1.44)

plot_model3_2017 = ggplot(model3_output_2017) +
  geom_hline(yintercept = 0, size = 0.1) +
  geom_point(mapping = aes(date, avg_v, shape=latin, color=latin), alpha = 0.6) +
  geom_line(mapping = aes(date, mean_model, linetype=latin, group=groupname)) +
  scale_x_date(date_labels = "%b %d") +
  ylim(0,3) +
  xlab("2017") +
  #ylab("Daily Mean Sap Velocity (mm/min)") +
  ylab("") + #remove label when using cowplot
  labs(color="Measured Values",
       shape="Measured Values",
       linetype="Mean Model") +
  guides(color = guide_legend(order=1),
         shape = guide_legend(order=1),
         linetype = guide_legend(order=2)) +
  ggtitle("Measured vs. Modeled Sap Velocity") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        #text=element_text(family="Times New Roman"),
        legend.text = element_text(face = "italic", size=10.5)) 
#theme(plot.title = element_text(hjust=0.5)) #centers title
plot_model3_2017

label2 = "(2)"
label3 = "(3)"
label4 = "(4)"
plot_model3_2017_labeled <- ggdraw(plot_model3_2017) +
                                     draw_label(label2, x = 0.15, y = 0.85, size = 10) +
                                     draw_label(label3, x = 0.40, y = 0.85, size = 10) +  
                                     draw_label(label4, x = 0.62, y = 0.85, size = 10)
plot_model3_2017_labeled


dataset_dry_2017 = filter(dataset_dry, date >= ymd("20170101")) %>%
  mutate(groupname = paste(period, "_", tree_index))
plot_model3_2017_std = ggplot(dataset_dry_2017) +
  geom_hline(yintercept = 0, size = 0.1) +
  geom_line(mapping = aes(date, avg_v_std, color=latin, group = groupname)) +
  scale_x_date(date_labels = "%b %d") +
  #scale_y_continuous(breaks=c(0,1,2), labels = c("0","1","")) +
  ylim(0,3) +
  xlab("2017") +
  ylab("") +
  #ylab("") +
  labs(color="Species") +
  ggtitle("Standardized Sap Velocity During Dry Periods") +
  theme_bw() +
  theme(legend.position = "right", #remove all legends (for cowplot)
        legend.text = element_text(face = "italic", size=10.5),   
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank()) 
        #text=element_text(family="Times New Roman"),
        #plot.title = element_text(hjust=0.5)) #centers title
plot_model3_2017_std

########### model 3: 2016 & 2017 combined results plot #######
# use cowplot to put 2016 and 2017 together:
plot_model_fit = plot_grid(plot_model3_2016_labeled, plot_model3_2017_labeled, 
          align = "h", rel_widths = c(3,10))

plot_std_data = plot_grid(plot_model3_2016_std, plot_model3_2017_std,
          align = "h", rel_widths = c(3,10))

plot_all_together = plot_grid(plot_model_fit, plot_std_data,
                            align = c("v"), ncol=1, labels="AUTO")
plot_all_together
ggsave(paste(wd_charts,"/Figure 5.tiff",sep=""), 
       units="in", width=8, height=8, dpi=600, compression = 'lzw')

################# Chart of other parameter values for Supplement C ######
other_params = data.frame(param = c("r_j"), values = as.vector(post3$r_mean_site)) %>%
  rbind(data.frame(param = c("r_diff"), values = as.vector(post3$r_diff))) %>%
  rbind(data.frame(param = c("r_jun_site_A"), values = as.vector(post3$r_jun_site[,1]))) %>%
  rbind(data.frame(param = c("r_jun_site_B"), values = as.vector(post3$r_jun_site[,2]))) %>%
  rbind(data.frame(param = c("r_jun_site_C"), values = as.vector(post3$r_jun_site[,3]))) %>%
  rbind(data.frame(param = c("r_jun_site_D"), values = as.vector(post3$r_jun_site[,4]))) %>%
  rbind(data.frame(param = c("r_jun_site_E"), values = as.vector(post3$r_jun_site[,5]))) %>%
  rbind(data.frame(param = c("r_jun_site_F"), values = as.vector(post3$r_jun_site[,6])))

ggplot(other_params) + 
  geom_violin(aes(values, fct_rev(factor(param))),draw_quantiles = c(0.025, 0.5, 0.975)) +
  geom_vline(xintercept=0, size = 0.2, color="gray") +
  ggtitle("Posterior Densities of Selected Parameters") +
  xlab("Posterior Densities") +
  ylab("Parameter") +
  scale_y_discrete(labels = c("r_j" = expression(paste(mu["J"])),
                              "r_diff" = expression(r["diff"]),
                              "r_jun_site_A" = expression(r["J"["A"]]),
                              "r_jun_site_B" = expression(r["J"["B"]]),
                              "r_jun_site_C" = expression(r["J"["C"]]),
                              "r_jun_site_D" = expression(r["J"["D"]]),
                              "r_jun_site_E" = expression(r["J"["E"]]),
                              "r_jun_site_F" = expression(r["J"["F"]]))) +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(), 
        #text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5)) #centers title
       
