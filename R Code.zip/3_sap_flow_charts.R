# !diagnostics off

options(stringsAsFactors = FALSE)
library(ggplot2)
library(readr)
library(lubridate)
library(magrittr)
library(dplyr)
library(extrafont)
library(cowplot)

# list of working directories USER SHOULD UPDATE
wd_input = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Input"
wd_output = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Output"
wd_charts = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Charts"

########### IMPORT DATA ####################################
sap_flow_2016 = read_csv(paste(wd_output, "/2016_sap_flow_output.csv", sep=""))
sap_flow_2017 = read_csv(paste(wd_output, "/2017_sap_flow_output.csv", sep=""))
sap_flow_2016$species = factor(sap_flow_2016$species, levels = c("juniper", "oak"))
sap_flow_2017$species = factor(sap_flow_2017$species, levels = c("juniper", "oak"))
sap_flow_2016$latin = "Q. fusiformis"
sap_flow_2016$latin[sap_flow_2016$species == "juniper"] = "J. ashei"
sap_flow_2017$latin = "Q. fusiformis"
sap_flow_2017$latin[sap_flow_2017$species == "juniper"] = "J. ashei"
sap_flow_2016$latin = factor(sap_flow_2016$latin, levels = c("J. ashei", "Q. fusiformis"))
sap_flow_2017$latin = factor(sap_flow_2017$latin, levels = c("J. ashei", "Q. fusiformis"))

########### graph Average Daily Sap Flow Velocity ################
poly_2016 = read_csv(paste(wd_input,"/polygon_2016.csv", sep="")) %>%
  mutate(x = mdy(x)) 
ds_adj_delim_2016 = data.frame(ds_2016_1_adj)

p_2016 = ggplot(sap_flow_2016) + 
  geom_polygon(poly_2016, mapping=aes(x,y), fill=colors()[241]) +
  geom_hline(yintercept=0, size=0.2, color="black") +
  geom_line(mapping=aes(date, avg_v, group=tree2, linetype=latin)) +
  facet_grid(facets = site~.) +
  ylim(0,4) +
  ggtitle("Mean daily sap velocity 2016") +
  xlab("") +
  ylab("Mean sap velocity (mm/min)") +
  labs(linetype="species") +
  theme(legend.position="bottom") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(), 
        plot.margin = unit(c(5.5, 5.5, 5.5, 20), "points"), 
        plot.title = element_text(hjust=0.5), #centers title
        legend.text = element_text(face = "italic"))
p_2016

poly_2017 = read_csv("polygon_2017.csv") %>%
  mutate(x = mdy(x)) %>%
  group_by(ds)
ds_2017_adj = c(ds_2017_1_adj, ds_2017_2_adj, ds_2017_3_adj)
ds_adj_delim_2017 = data.frame(ds_2017_adj)

p_2017 = ggplot(sap_flow_2017) + 
  geom_polygon(poly_2017, mapping=aes(x,y,group=ds), fill=colors()[241]) +
  geom_hline(yintercept=0, size=0.2, color="black") +
  geom_line(mapping=aes(date, avg_v, linetype=latin, group=tree)) +
  facet_grid(site~.) +
  ylim(0,4) +
  ggtitle("Mean daily sap velocity 2017") +
  xlab("") +
  ylab("Mean sap velocity (mm/min)") +
  labs(linetype="species") +
  theme(legend.position="bottom") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(), 
        plot.margin = unit(c(5.5, 5.5, 5.5, 20), "points"), 
        plot.title = element_text(hjust=0.5), #centers title
        legend.text = element_text(face = "italic"))
p_2017

plot_grid(p_2016, p_2017, align=c("v"), ncol=1, labels = "AUTO")
ggsave(paste(wd_charts,"/Figure 3.tiff",sep=""), 
       units="in", width=6, height=6, dpi=600, compression = 'lzw')

########## First and last days of each dry period #####################
sap_data_ds_2016_0 = 
  filter(sap_data_2016_15min, 
         date == ymd("20160724"))
sap_data_ds_2016_1 = 
  filter(sap_data_2016_15min, 
         date == ds_2016_1_adj[1])
sap_data_ds_2016_2 = 
  filter(sap_data_2016_15min, 
         date == ds_2016_1_adj[2])
sap_data_ds_2016_3 = 
  filter(sap_data_2016_15min, 
         date == ymd("20160918"))
sap_data_ds_2016_4 = 
  filter(sap_data_2016_15min, 
         date == ymd("20161010"))
sap_data_ds_2016=rbind(sap_data_ds_2016_0, sap_data_ds_2016_1, sap_data_ds_2016_2, sap_data_ds_2016_3, sap_data_ds_2016_4)
ggplot(sap_data_ds_2016, mapping=aes(time_dec, v, color=tree, group=tree2)) + 
  geom_line() +
  facet_grid(species ~ date) +
  ggtitle("Start and end dates of 2016 dry period") +
  xlab("hour") +
  ylab("sap flow velocity (mm/min)") +
  theme_bw() + #removes gray background
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),  #removes grid lines
        text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5),
        legend.position="none") 

sap_data_ds_2017_1 = 
  filter(sap_data_2017_15min,
         date %in% c(ds_2017_1_adj[1]+9,ds_2017_1_adj[2]))
# note that start date is adjustable above, depending on how many trees one wants to capture
ggplot(sap_data_ds_2017_1, mapping=aes(time_dec, v, color=species, group=tree2)) + 
  geom_line() +
  facet_grid(species ~ date) +
  ggtitle("First and last dates of first 2017 dry period") +
  xlab("hour") +
  ylab("sap velocity (mm/min)") +
  theme_bw() + #removes gray background
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),  #removes grid lines
        text=element_text(family="Times New Roman"),
        plot.title = element_text(hjust=0.5),
        legend.position="none")   

sap_data_ds_2017_2 = 
  filter(sap_data_2017_15min,
         date %in% c(ds_2017_2_adj[1],ds_2017_2_adj[2])) %>%
  mutate(latin = "")
sap_data_ds_2017_2$latin[sap_data_ds_2017_2$species == "juniper"] <- "J. ashei"
sap_data_ds_2017_2$latin[sap_data_ds_2017_2$species == "oak"] <- "Q. fusiformis"

ggplot(sap_data_ds_2017_2, mapping=aes(time_dec, v, color=species, group=tree2)) + 
  geom_line() +
  facet_grid(latin ~ date) +
  ggtitle("Start and End of Longest 2017 Dry Period") +
  xlab("Hour of Day") +
  ylab("Sap Velocity (mm/min)") +
  theme_bw() + #removes gray background
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),  #removes grid lines
        plot.title = element_text(hjust=0.5),
        legend.position="none", 
        strip.text.y = element_text(face = "italic"))
ggsave(paste(wd_charts,"/Figure 4.tiff",sep=""), 
       units="in", width=6, height=6, dpi=600, compression = 'lzw')

sap_data_ds_2017_3 = 
  filter(sap_data_2017_15min,
         date %in% c(ds_2017_3_adj[1],ds_2017_3_adj[2]))
ggplot(sap_data_ds_2017_3, mapping=aes(time_dec, v, color=species, group=tree2)) + 
  geom_line() +
  facet_grid(species ~ date) +
  ggtitle("Start and end dates of 2017's 3rd dry period") +
  xlab("hour") +
  ylab("sap flow velocity (mm/min)")

