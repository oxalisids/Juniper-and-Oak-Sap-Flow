# !diagnostics off

options(stringsAsFactors = FALSE)
library(lubridate)
library(dplyr)
library(ggplot2)
library(readr)
library(magrittr)

# list of working directories USER SHOULD UPDATE
wd_input = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Input"
wd_output = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Output"
wd_charts = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Charts"

########### IMPORT 2016 DATA #############################
setwd(wd_input)
start_date_2016 = ymd("20160725")
tree_table_2016 = read.csv("2016 tree table.csv")
low.data.2016 = read.csv("2016 sap flow - site C.csv")
mid.data.2016 = read.csv("2016 sap flow - site B.csv")
high.data.2016 = read.csv("2016 sap flow - site A.csv")

# fix date formatting
low.data.2016$Date = as.Date(low.data.2016$Date, format = "%m/%d/%y")
mid.data.2016$Date = as.Date(mid.data.2016$Date, format = "%m/%d/%y")
high.data.2016$Date = as.Date(high.data.2016$Date, format = "%m/%d/%y")

# fix wrong year in high dataset
year(high.data.2016$Date) = 2016

########### IMPORT 2017 DATA #############################
start_date_2017 = ymd("20170620")
tree_table_2017 = read.csv("2017 tree table.csv")
low.data.2017 = read.csv("2017 sap flow - site F.csv")
mid.data.2017 = read.csv("2017 sap flow - site E.csv")
high.data.2017 = read.csv("2017 sap flow - site D.csv")

# fix date formatting
low.data.2017$Date = as.Date(low.data.2017$Date, format = "%m/%d/%y")
mid.data.2017$Date = as.Date(mid.data.2017$Date, format = "%m/%d/%y")
high.data.2017$Date = as.Date(high.data.2017$Date, format = "%m/%d/%y")

########### FUNCTION THAT AGGREGATES VERTICAL SAP DATASET ############
vertical_data = function(low_data, mid_data, high_data, tree_table, data_year){
  # initialize columns
  table_date_time = c()
  table_date = c()
  table_month = c()
  table_time = c()
  table_site = c()
  table_species = c()
  table_tree = c()
  table_mV = c()
  table_dT = c()
  
  for (i in 1:nrow(tree_table)){
    # add data to columns for each tree
    dataset_name = as.character(tree_table$dataset[i]) 
    dataset = eval(parse(text=dataset_name)) # evaluates the dataset-name string as a variable name
    column_name = as.character(tree_table$column[i])
    if (!is.na(column_name)){
      site = as.character(tree_table$site_new[i])
      species = as.character(tree_table$species[i])
      tree_number = as.character(tree_table$tree_num[i])
      rows = nrow(dataset)
      
      table_date = c(table_date, dataset$Date)
      table_month = c(table_month, month(dataset$Date))
      table_time = c(table_time, dataset$Time)
      table_site = c(table_site, rep(site, each = rows))
      table_species = c(table_species, rep(species, each = rows))
      table_tree = c(table_tree, rep(tree_number, each = rows))
      table_mV = c(table_mV, eval(parse(text = paste(dataset_name, "$",column_name, sep = ""))))
    } # end if
  } # end for
  
  class(table_date) = "Date"
  sap_data = data.frame(table_date, table_month, table_time, table_site, 
                        table_species, table_tree, table_mV)
  colnames(sap_data) = c("date", "month", "time", "site", "species", "tree", "mV")
  
  # create date_time and time_dec columns for graphing, and calculate dT from mV
  sap_data <- mutate(sap_data,
                     date_time = as.POSIXct(paste(date," ",time,":00", sep = "")),
                     time_dec = gsub(":", ".", time),
                     dT = 25* mV) %>%
    mutate(time_dec = as.numeric(time_dec),
           time_dec = time_dec %/% 1 + (time_dec %% 1)*100/60,
           day_time_dec = mday(date) - 1 + time_dec/24,
           bad_data = FALSE)
  return(sap_data)
} # end function

sap_data_2016 = vertical_data(low.data.2016, mid.data.2016, high.data.2016, 
                              tree_table_2016, 2016)  
sap_data_2017 = vertical_data(low.data.2017, mid.data.2017, high.data.2017,
                               tree_table_2017, 2017)

########### OUTLIERS FUNCTION REMOVES BAD DATA ########################

#  outliers = function that filters out bad data
#    lower_bound = lower bound of acceptable dT values
#    upper_bound = upper bound of acceptable dT values
#    max_drop = maximum allowable drop in value from one point to the next 
#         per unit time; second point is removed
#    max_jump = maximum allowable jump in value from one point to the next
#         per unit time; first point is removed
#    max_wiggle = maximum allowable differance from any given point to the points
#         before and after it, assuming pattern is down-up-down or up-down-up (=wiggle)
#    n = number of iterations

outliers = function(sap_data, lower_bound, upper_bound, max_drop, max_jump, max_wiggle, n){
  # make sure sap_data input already has bad_data column!
  # this does not default bad_data to FALSE at beginning of run; do manually
  print(nrow(sap_data))
  sap_data_output = sap_data
  sap_data_output$bad_data[sap_data_output$dT < lower_bound] <- TRUE
  sap_data_output$bad_data[sap_data_output$dT > upper_bound] <- TRUE

  sap_data_temp <- filter(sap_data_output, bad_data==FALSE)
  group_by(sap_data_temp, tree)
  print(nrow(sap_data_temp))
  
  # iterative filtering removes a few rows each time. 
  for (i in 1:n){
    sap_data_temp <- mutate(sap_data_temp,
                            time_diff1 = 24*(as.numeric(julian(date)) -
                                             as.numeric(julian(lag(date,n=1)))) +
                                         (time_dec-lag(time_dec,1)),
                            diff1 = dT-lag(dT,n=1),
                            diff1_time_adj = (dT-lag(dT,n=1))/(time_diff1/.25),
                            
                            diff2 = lead(dT,n=1)-lag(dT,n=1),
                            diff2_tree = lead(tree,n=1)==lag(tree,n=1),
                            
                            time_diff3 = 24*(as.numeric(julian(lead(date,n=1))) -
                                             as.numeric(julian(date))) +
                                         (lead(time_dec,1) - time_dec),
                            diff3 = lead(dT,n=1)-dT,
                            diff3_time_adj = (lead(dT,n=1)-dT)/(time_diff3/.25),
                            test_wiggle = pmax(abs(diff1),abs(diff3)) - abs(diff2) 
                            )
    sap_data_temp$bad_data[sap_data_temp$test_wiggle > max_wiggle &
                           !is.na(sap_data_temp$diff2_tree) &
                           sap_data_temp$diff2_tree != FALSE] <- TRUE
    sap_data_temp$bad_data[sap_data_temp$diff1_time_adj < max_drop &
                           !is.na(sap_data_temp$diff2_tree) & 
                           sap_data_temp$diff2_tree != FALSE] <- TRUE
    sap_data_temp$bad_data[sap_data_temp$diff3_time_adj > max_jump &
                           !is.na(sap_data_temp$diff2_tree) & 
                           sap_data_temp$diff2_tree != FALSE] <- TRUE
    #View(filter(sap_data_temp,tree=="Mid-Oak8", date==ymd("20160928")))
    
    sap_data_temp$bad_data2 = sap_data_temp$bad_data #change the name to avoid confusion while joining tables
    sap_data_output <- left_join(sap_data_output,
                                 select(sap_data_temp, date_time, tree, bad_data2),
                                 by=c("date_time", "tree"))
    sap_data_output$bad_data[!is.na(sap_data_output$bad_data2)] =
      sap_data_output$bad_data2[!is.na(sap_data_output$bad_data2)]
    sap_data_output <- sap_data_output[, 1:ncol(sap_data_output)-1]
    
    sap_data_temp <- filter(sap_data_temp, bad_data==FALSE)
    print(nrow(sap_data_temp))
  }
  
  #Remove points surrounded by bad values
  sap_data_output <- mutate(sap_data_output,
                            sandwich = lag(bad_data,1) & lead(bad_data,1),
                            sandwich2a = lag(bad_data,2) & lead(bad_data,1),
                            sandwich2b = lag(bad_data,1) & lead(bad_data,2)
                           )
  sap_data_output$bad_data[sap_data_output$sandwich == TRUE |
                           sap_data_output$sandwich2a == TRUE |
                           sap_data_output$sandwich2b == TRUE] <- TRUE
  print(nrow(filter(sap_data_output, bad_data==FALSE)))
  sap_data_output <- sap_data_output[, 1:(ncol(sap_data_output)-3)]
  
  return(sap_data_output)
}

########### FUNCTION TO PLOT DATASETS BY TREE AND SAVE AS FILES ##################
plot_tree_data = function(year, dataset, tree_table, wd, yvar, yaxis, yl = -0.1, yh = 10){
  tree_list = filter(tree_table, !is.na(column))$tree_num
  
  for (t in tree_list){
    month_list = unique(filter(dataset, tree==t)$month)
    chart_title = paste(year," ",t, sep="")
    p <- ggplot(filter(dataset, tree==t), 
               aes_string(x="day_time_dec", y=yvar)) +
          geom_line(data=filter(dataset, tree==t, bad_data==FALSE), color="gray") +
          geom_point(aes(color=bad_data), size=0.9) +
          facet_grid(month~.) +
          ggtitle(chart_title) +
          xlab("day of month") +
          ylab(yaxis) +
          ylim(yl,yh)
    chart_name <- paste("plot_",year,"_",t,".jpeg",sep="")
    chart_path <- paste(wd,"/",chart_name,sep="")
    jpeg(file=chart_path, width=1072, height=603, quality=100)
    print(p)
    dev.off()
  }
}

########### REMOVE BAD DATA ############################
sap_data_2016$bad_data<-FALSE
sap_data_2017$bad_data<-FALSE
# outliers(data, lower_bound, upper_bound, max_drop, max_jump, max_wiggle, number of iterations)
sap_data_2016_clean = outliers(sap_data_2016, 1.7, 10, -0.7, 1.0, 0.5, 5)
sap_data_2017_clean = outliers(sap_data_2017, 1.7, 10, -0.7, 1.0, 0.5, 5)
# lower_bound limited to 1.7 by 2017 Low-Oak1
# max_drop limited to 1.0 by 2016 High-Oak1 and Low-Jun4
# max wiggle not limited by any tree in particular, but 0.5 seems reasonable
# sandwich did not remove any additional points.

# Mark as bad data for Low-Jun9 for 08/16/2016 - 08-27/2016 since it appeared to be
# affected by rain and had negative values then was extremely unstable
jun9_bad_dates = sap_data_2016_clean$tree == "Low-Jun9" &
                 sap_data_2016_clean$date >= ymd("20160816") &
                 sap_data_2016_clean$date <= ymd("20160827")
sap_data_2016_clean$bad_data[jun9_bad_dates] <- TRUE

#create directories for charts
dir_2016 = paste(wd_charts,"/2016 tree plots - raw data",sep="")
dir_2017 = paste(wd_charts,"/2017 tree plots - raw data",sep="")
dir.create(dir_2016)
dir.create(dir_2017)

#create charts of raw sap flow data showing bad data
#there is a separate chart for each tree to visualize the data. 
#Bad data is colored aqua/blue. Good data is coral/red.
plot_tree_data(2016, sap_data_2016_clean, tree_table_2016, dir_2016, 
               "dT", "temp. differential (Celsius)")
plot_tree_data(2017, sap_data_2017_clean, tree_table_2017, dir_2017, 
               "dT", "temp. differential (Celsius)")
# note errors in plot_tree_data(2017, ...) are caused by points that are not graphed because
# they fall outside specified y-axis range limits

#Plot of raw data for a single tree on a single day (specify tree and day)
ggplot(filter(sap_data_2017_clean,tree=="High-Oak5", date==ymd("20170626")), 
       aes(x=date_time, y=dT)) +
  geom_line(color="gray") +
  geom_point(aes(color=bad_data))

# Remove data for Low-Jun9 for 08/16/2016 - 08-27/2016 since it appeared to be
# affected by rain and had negative values then was extremely unstable
sap_data_2016_clean = sap_data_2016_clean[!jun9_bad_dates,]
# Remove first data point for Low-Jun4 on 07/23/2016, as it appeared to be warming up
jun4_bad_data = sap_data_2016_clean$tree == "Low-Jun4" &
                sap_data_2016_clean$date == ymd("20160723") &
                sap_data_2016_clean$time_dec <= 10.75
sap_data_2016_clean = sap_data_2016_clean[!jun4_bad_data,]

########### NEW TREE LABELS ######################################
# the point of this code is to divide each tree's data into cohesive sections
# to be used for charts, so that different sections will not be connected by line.
section_data = function(sap_data_clean, gap_width){
  sap_data_output = mutate(sap_data_clean,
                           tree2 = NA,  #just want this at the beginning of these columns
                           tree_test_1 = tree != ifelse(is.na(lag(tree,1)),"wrong",lag(tree,1)),
                           tree_test_2 = ifelse(tree_test_1==TRUE, 
                                                FALSE, 
                                                (date_time - lag(date_time,1))/(24*60) >= gap_width
                                                ),
                           tree_test_3 = 1*tree_test_1 + 1*tree_test_2
                           ) %>%
  group_by(tree) %>%
  mutate(tree_test_4 = cumsum(tree_test_3),
         tree2 = paste(tree, letters[tree_test_4], sep="")) %>%
  ungroup()
  sap_data_output = sap_data_output[, 1:(ncol(sap_data_output)-4)]
  return(sap_data_output)
}

sap_data_2016_clean2 = section_data(sap_data_2016_clean, 1)
sap_data_2017_clean2 = section_data(sap_data_2017_clean, 1)

########### SAP FLOW CALCULATION ###################################

# calculate dT_max for each tree and dT_day_max for each tree and day
sap_flow_calc = function(sap_data_clean2, a, b){  
  sap_data_good <- filter(sap_data_clean2, bad_data == FALSE)
  dT_max_table <- unique(data.frame(sap_data_good$tree, sap_data_good$date))
  colnames(dT_max_table) = c("tree", "date")

  # for each tree and day, find the maximum value of dT between midnight and 7:00 am
  # (to use for the sap flow formula)
  dT_max_table_temp <- group_by(sap_data_good, tree, date) %>%
    filter(hour(date_time) <= 7) %>%
    mutate(dT_day_max = max(dT)) %>%
    ungroup() %>%
    select(tree, date, dT_day_max) %>%
    unique()
  
  #For days that did not have any data between midnight and 7:00 am, fill in with
  #dT_day_max from the following day. This includes the first day for each tree.
  dT_max_table <- left_join(dT_max_table, dT_max_table_temp) %>%
    group_by(tree) %>% 
    mutate(dT_day_max=ifelse(is.na(dT_day_max), 
                             mean(c(lead(dT_day_max, 1), lag(dT_day_max,1)), na.rm=TRUE), 
                             dT_day_max))

  sap_data_calc <- left_join(sap_data_clean2, dT_max_table)
  
  ##### ONE-OFF CORRECTION, 2016 High-Oak1, 10/11/2016 ################  
  # to recalibrate and eliminate singularity, use dT_day_max from 
  # following day, rather than same day.
  sap_data_calc$dT_day_max[sap_data_calc$tree=="High-Oak1" &
                             sap_data_calc$date==ymd("20161005")] <- 5.975
  ##### ONE-OFF CORRECTION, 2017 High-Jun6, 7/27/2017 ################  
  # to recalibrate and eliminate singularity, use dT_day_max from 
  # following day, rather than same day.
  sap_data_calc$dT_day_max[sap_data_calc$tree=="High-Jun6" &
                           sap_data_calc$date==ymd("20170727") &
                           sap_data_calc$time_dec >= 0.75] <- 4.625 
                           
  # calculate sap flow velocity
  # note that I am setting K's that come out negative to zero - may cause some bias. 
  # this issue is caused by the 7:00 am cutoff above.
  sap_data_calc <- mutate(sap_data_calc, 
                     K_raw = (dT_day_max - dT)/dT,
                     K = pmax((dT_day_max - dT)/dT, 0),
                     v = a * (K ^ b) * 10 * 60
                     )
  #Set values to NA when bad_data == TRUE
  sap_data_calc$K[sap_data_calc$bad_data==TRUE] <- NA
  sap_data_calc$v[sap_data_calc$bad_data==TRUE] <- NA
  return(sap_data_calc)
}

# Using original Granier 1985 parameters
sap_data_2016_calc = sap_flow_calc(sap_data_2016_clean2, 0.0119, 1.231)
sap_data_2017_calc = sap_flow_calc(sap_data_2017_clean2, 0.0119, 1.231)
# Check for negative K values/inverted days
sap_data_2016_Kcheck = filter(sap_data_2016_calc, K_raw<0) %>%  # filter for negative K values
  group_by(tree, date, time) %>% 
  summarise(n =n(), minK = min(K_raw), time_dec = min(time_dec)) %>%
  filter(time_dec<18) %>% # filter out times that are after 6:00 pm since those are more related to following day
  ungroup() %>%
  group_by(tree, date) %>%
  summarise(n=n(), minK=min(minK), min_time = min(time_dec), max_time = max(time_dec))
#View(sap_data_2016_Kcheck)
sap_data_2017_Kcheck = filter(sap_data_2017_calc, K_raw<0) %>%  # filter for negative K values
  group_by(tree, date, time) %>% 
  summarise(n =n(), minK = min(K_raw), time_dec = min(time_dec)) %>%
  filter(time_dec<18) %>% # filter out times that are after 6:00 pm since those are more related to following day
  ungroup() %>%
  group_by(tree, date) %>%
  summarise(n=n(), minK=min(minK), min_time = min(time_dec), max_time = max(time_dec))
#View(sap_data_2017_Kcheck)

########### use linear approx to fill in missing data points #####################
# This step is necessary to take integrals of v over the day.
# Tried cubic spline first, but that was creating more error when it would
# somtimes shoot up way past the data's max

fill_missing_values = function(sap_data_calc, tree_table){ 
  # Initialize final dataset
  sap_data_final = sap_data_calc[0,]
  tree_table = filter(tree_table, !is.na(column))
  
  for(t in tree_table$tree_num){
    temp = filter(sap_data_calc, tree==t)
    if (nrow(temp)>0){
      #f = splinefun(temp$date_time,temp$v)
      f = approxfun(temp$date_time, temp$v, "linear")
      temp$v[temp$bad_data==TRUE]=f(temp$date_time[temp$bad_data==TRUE])
      sap_data_final = rbind(sap_data_final, temp)
    }
  }
  return(sap_data_final)
}
 
# note that lines with bad_data==TRUE have values filled in by spline
# tables with Granier 1985 parameters
sap_data_2016_final = fill_missing_values(sap_data_2016_calc, tree_table_2016)
sap_data_2017_final = fill_missing_values(sap_data_2017_calc, tree_table_2017)
sap_data_2016_final$site = factor(sap_data_2016_final$site, levels = c("A", "B", "C"))
sap_data_2017_final$site = factor(sap_data_2017_final$site, levels = c("D", "E", "F")) 

dir_2016_final = paste(wd_charts, "/2016 tree plots - final sap flow calc", sep="")
dir_2017_final = paste(wd_charts, "/2017 tree plots - final sap flow calc", sep="")
dir.create(dir_2016_final)
dir.create(dir_2017_final)

plot_tree_data(2016, sap_data_2016_final, tree_table_2016, dir_2016_final, 
               "v", "sap flow (mm/min)")
plot_tree_data(2017, sap_data_2017_final, tree_table_2017, dir_2017_final, 
               "v", "sap flow (mm/min)")

########### average daily values (integrate) ################################
sap_data_2016_day_avg = sap_data_2016_final %>%
  #filter(date >= start_date_2016) %>%
  #filter(!(site=="A" & date>ymd("20161001"))) %>%
  group_by(tree, tree2, species, site, date) %>%
  summarise(
    total_v = sum(v),
    count = n(),
    avg_v = mean(v),
    max_v = max(v)
  ) %>%
  filter(count>=0.9*96)  #I cut some more data here.

sap_data_2017_day_avg = sap_data_2017_final %>%
  #filter(date >= start_date_2017) %>%
  group_by(tree, tree2, species, site, date) %>%
  summarise(
    total_v = sum(v),
    count = n(),
    avg_v = mean(v),
    max_v = max(v)
  ) %>%
  filter(count >= (0.9*96)) 

########### calculate scaled values ##############################
scale_date_2016 = ymd("20160728")
scale_date_2016 = ymd("20170728")

sap_data_2016_day_avg <- group_by(sap_data_2016_day_avg, tree) %>%
  mutate(normalized = avg_v/max(avg_v)) %>%
  ungroup()

sap_data_2017_day_avg <- group_by(sap_data_2017_day_avg, tree) %>%
  mutate(normalized = avg_v/max(avg_v)) %>%
  ungroup()

########### export final table ###################################
write.csv(sap_data_2016_final, paste(wd_output,"/2016_sap_flow_output_15min.csv", sep=""))
write.csv(sap_data_2017_final, paste(wd_output,"/2017_sap_flow_output_15min.csv", sep=""))
write_csv(sap_data_2016_day_avg, paste(wd_output,"/2016_sap_flow_output.csv", sep=""))
write_csv(sap_data_2017_day_avg, paste(wd_output,"/2017_sap_flow_output.csv", sep=""))

