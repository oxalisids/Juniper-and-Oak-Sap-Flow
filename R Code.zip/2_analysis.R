# !diagnostics off

options(stringsAsFactors = FALSE)
library(dplyr)
library(ggplot2)
library(readr)
library(lubridate)
library(chron)
library(stats) # for nls and splinefun functions
library(reshape2)
library(magrittr)

# list of working directories USER SHOULD UPDATE
wd_input = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Input"
wd_output = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Output"
wd_charts = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Charts"

################# IMPORT DATA #############################
setwd(wd_input)
tree_table_2016 = read_csv("2016 tree table.csv")
tree_table_2017 = read_csv("2017 tree table.csv")
sap_data_2016 = read_csv(paste(wd_output, "/2016_sap_flow_output.csv", sep=""))
sap_data_2017 = read_csv(paste(wd_output, "/2017_sap_flow_output.csv", sep=""), col_types = cols(site = col_character()))
sap_data_2016_15min = read_csv(paste(wd_output, "/2016_sap_flow_output_15min.csv", sep=""))
sap_data_2017_15min = read_csv(paste(wd_output, "/2017_sap_flow_output_15min.csv", sep=""), col_types = cols(site = col_character()))

########### calculate correlations between trees #########################
correlations_2016 = select(sap_data_2016, date, tree, avg_v) %>%
  dcast(date ~ tree)
correlations_2016 = cor(correlations_2016[,2:13], use = "pairwise.complete.obs")
write.csv(correlations_2016, paste(wd_output,"/correlations_2016.csv", sep=""))

correlations_2017 = select(sap_data_2017, date, tree, avg_v) %>%
  dcast(date ~ tree)
correlations_2017 = cor(correlations_2017[,2:12], use = "pairwise.complete.obs")
write.csv(correlations_2017, paste(wd_output,"/correlations_2017.csv", sep=""))

########### critical dry spells ##############################################
# These dry spells were determined as periods between rainfall events of at least 0.5 cm
# during which the Barton Creek stream discharge rate (m^3/2) fell into the lowest
# decile during the two-year period 2016-2017, as described in the main paper.
ds_2016_1 = c(ymd("20160728"), ymd("20160813"))
ds_2017_1 = c(ymd("20170606"), ymd("20170625"))
ds_2017_2 = c(ymd("20170627"), ymd("20170806"))
ds_2017_3 = c(ymd("20170808"), ymd("20170824"))

# Find maxima for each dry period
ds_2016_1_max = filter(sap_data_2016, date >= ds_2016_1[1], date <= ds_2016_1[2]) %>%
                group_by(tree) %>%
                summarize(avg_v = max(avg_v)) %>%
                left_join(select(sap_data_2016, tree, date, avg_v))
ds_2016_1_max = ds_2016_1_max[order(ds_2016_1_max$date),] # 2016-7-29

ds_2017_1_max = filter(sap_data_2017, !is.na(avg_v),
                       date >= ds_2017_1[1], date <= ds_2017_1[2]) %>%
  group_by(tree) %>%
  summarize(avg_v = max(avg_v)) %>%
  left_join(select(sap_data_2017, tree, date, avg_v))
ds_2017_1_max = ds_2017_1_max[order(ds_2017_1_max$date),]  # not sensical

ds_2017_2_max = filter(sap_data_2017, !is.na(avg_v),
                       date >= ds_2017_2[1], date <= ds_2017_2[2]) %>%
  group_by(tree) %>%
  summarize(avg_v = max(avg_v)) %>%
  left_join(select(sap_data_2017, tree, date, avg_v))
ds_2017_2_max = ds_2017_2_max[order(ds_2017_2_max$date),]  # 2017-6-29

ds_2017_3_max = filter(sap_data_2017, !is.na(avg_v),
                       date >= ds_2017_3[1], date <= ds_2017_3[2]) %>%
  group_by(tree) %>%
  summarize(avg_v = max(avg_v)) %>%
  left_join(select(sap_data_2017, tree, date, avg_v))
ds_2017_3_max = ds_2017_3_max[order(ds_2017_3_max$date),]  # 2017-8-11

# The raw dry periods are adjusted to include days where the median tree has decreasing sap flow.
# This affects dry periods 2 and 3.
ds_2016_1_adj = c(ymd("20160729"), ymd("20160812")) #removed 1 rain day at beginning and 1 at end
ds_2017_1_adj = c(ymd("20170610"), ymd("20170623")) #removed non-measuring days at beginning and 2 rain days at end
ds_2017_2_adj = c(ymd("20170629"), ymd("20170806")) # removed 1 rain day and one other day at beginning
ds_2017_3_adj = c(ymd("20170811"), ymd("20170824")) # removed 3 days at beginning









