# !diagnostics off

options(stringsAsFactors = FALSE)
library(dplyr)
library(ggplot2)
library(readr)

# list of working directories USER SHOULD UPDATE
wd_input = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Input"
wd_output = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Output"
wd_charts = "/Users/Alison/Desktop/Biology/Dissertation/Ch1 data and code/Charts"

########### predawn water potential ############################
setwd(wd_input)
wp.data.2016 = read.csv("2016 predawn_wp_data.csv")
wp.data.2016$date = as.Date(wp.data.2016$date, format = "%m/%d/%y")
tree_table_2016 = read.csv("2016 tree table.csv")

wp_2016 = left_join(wp.data.2016, tree_table_2016, by = c("tree"="tree_num"))
wp_2016$site_new = factor(wp_2016$site_new, levels = c("A", "B", "C"))
wp_2016$species = factor(wp_2016$species, levels = c("juniper", "oak"))
wp_2016$latin = factor(wp_2016$latin, levels = c("J. ashei", "Q. fusiformis"))

# format dates for charts
date_orig = unique(wp_2016$date)
date_format = c("Jul 29", "Aug 12", "Sep 6")
date_table = data.frame(date_orig, date_format)
colnames(date_table) = c("date", "date_chart")
wp_2016 = left_join(wp_2016, date_table, by = c("date"))

# P50 measurements
p50_oak <- -1.8
p50se_oak <- 0.8
p50_jun <- -13.1
p50se_jun <- 1.2
p50_oak_chart <- data.frame( x = c(-Inf, Inf), y = p50_oak, species = factor("oak"), latin = factor("Q. fusiformis"))
p50_jun_chart <- data.frame( x = c(-Inf, Inf), y = p50_jun, species = factor("juniper"), latin = factor("J. ashei"))
p50_chart <- rbind(p50_jun_chart, p50_oak_chart)
poly_p50se = read_csv("polygon_P50SE.csv") %>%
  group_by(latin)

# chart with all data
p_wp_2016 = ggplot(filter(wp_2016,quality=="high"), 
                   mapping = aes(x = date, y = wp_MPa, group=tree, col = species)) + 
  geom_point() +
  facet_grid(site_new ~ .) +
  #ylim(0,12) +
  ggtitle("Predawn Water Potential, Summer 2016") +
  xlab("Date") +
  ylab("Water Potential (MPa)") +
  theme_bw()
p_wp_2016

###### final plot for paper ##########
wp_2016_summary = wp_2016 %>%
  group_by(date, date_chart, tree2, quality, site, site_new, species, latin) %>%
  summarise(max = max(wp_MPa),
            min = min(wp_MPa),
            avg = mean(wp_MPa))
wp_2016_summary$date = as.factor(wp_2016_summary$date)
wp_2016_summary$date_chart = factor(wp_2016_summary$date_chart, levels = date_format)

ggplot(filter(wp_2016_summary, quality=="high"), mapping = aes(x = date_chart, y = avg)) + 
  geom_polygon(poly_p50se, mapping=aes(x,y, group=latin, fill=latin), 
               alpha = 0.2) +
  geom_line(data = p50_chart, mapping = aes( x, y, group=latin, color=latin)) +
  geom_line(mapping = aes(group=tree2, linetype=latin), color="black") +
  geom_point(mapping = aes(group = tree2, shape=latin), size=2, color="black", fill="white") +
  scale_shape_manual(values=c(21, 24)) +
  facet_grid(. ~ site_new) +
  ylim(-15,0) + #full chart
  #ylim(-4,0) + # just the top, to join using photo editing
  #ylim(-15,-11) + # just the bottom, to join using photo editing
  ggtitle("Predawn Water Potential 2016") +
  xlab("Date") +
  ylab("Water Potential (MPa)") +
  labs(linetype="PWP",
       shape="PWP",
       color=expression(paste(Psi[50]%+-%"SE")),
       fill=expression(paste(Psi[50]%+-%"SE"))) +
  guides(linetype = guide_legend(order=1),
         shape = guide_legend(order=1),
         color = guide_legend(order=2),
         fill = guide_legend(order=2)) +
  theme_bw() + #removes gray background
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        legend.text = element_text(face = "italic", size=10.5)) + #removes grid lines
  theme(plot.title = element_text(hjust=0.5)) #centers title

